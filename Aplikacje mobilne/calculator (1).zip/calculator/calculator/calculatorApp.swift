//
//  calculatorApp.swift
//  calculator
//
//  Created by Student15 on 21/05/2024.
//

import SwiftUI

@main
struct calculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
