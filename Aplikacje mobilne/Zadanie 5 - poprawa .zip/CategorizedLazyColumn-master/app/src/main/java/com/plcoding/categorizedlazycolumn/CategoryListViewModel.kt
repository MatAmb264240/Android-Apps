package com.plcoding.categorizedlazycolumn

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class CategoryListViewModel : ViewModel() {
    val namesList = mutableStateOf(names.map { Category(it.key.toString(), it.value) })
    var editedItem: String by mutableStateOf("")
    var isEditing: Boolean by mutableStateOf(false)

    fun addItem(newItem: String) {
        if (newItem.isNotEmpty()) {
            val categoryIndex = namesList.value.indexOfFirst { it.name == newItem.first().toString() }
            if (categoryIndex != -1) {
                val updatedCategory = namesList.value[categoryIndex].copy(
                    items = namesList.value[categoryIndex].items + newItem
                )
                val updatedNamesList = namesList.value.toMutableList().apply {
                    set(categoryIndex, updatedCategory)
                }
                namesList.value = updatedNamesList
            } else {
                val updatedNamesList = namesList.value.toMutableList().apply {
                    add(Category(name = newItem.first().toString(), items = listOf(newItem)))
                }
                namesList.value = updatedNamesList
            }
        }
    }

    fun removeItem(removedItem: String) {
        val updatedNamesList = namesList.value.map { category ->
            category.copy(
                items = category.items.filterNot { it == removedItem }
            )
        }
        namesList.value = updatedNamesList
    }

    fun editItem(newEditedValue: String) {
        val updatedNamesList = namesList.value.map { category ->
            category.copy(
                items = category.items.map { item ->
                    if (item == editedItem) newEditedValue else item
                }
            )
        }
        namesList.value = updatedNamesList
    }
}