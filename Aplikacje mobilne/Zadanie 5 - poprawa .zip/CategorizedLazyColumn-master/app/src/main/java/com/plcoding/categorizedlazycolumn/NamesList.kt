package com.plcoding.categorizedlazycolumn

val names = mutableListOf(
    "Informatyka",
    "Automatyka i robotyka",
    "Elektronika i telekomunikacja",
    "Inżynieria biomedyczna",
    "Inżynieria chemiczna i procesowa",
    "Inżynieria materiałowa",
    "Inżynieria środowiska",
    "Inżynieria mechaniczna",
    "Inżynieria środowiska",
    "Inżynieria produkcji",
    "Matematyka stosowana",
    "Mechatronika",
    "Teleinformatyka",
    "Fizyka techniczna"
).groupBy {
    it.first()
}.toSortedMap()