@file:OptIn(ExperimentalFoundationApi::class)

package com.plcoding.categorizedlazycolumn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.plcoding.categorizedlazycolumn.ui.theme.CategorizedLazyColumnTheme



class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CategorizedLazyColumnTheme {
                Surface(
                    color = MaterialTheme.colorScheme.background
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        val viewModel: CategoryListViewModel = viewModel()

                        AddItemSection(onAddClick = viewModel::addItem)
                        CategorizedLazyColumn(
                            categories = viewModel.namesList.value,
                            modifier = Modifier.weight(1f),
                            onItemRemove = viewModel::removeItem,
                            onItemEdit = { item ->
                                viewModel.editedItem = item
                                viewModel.isEditing = true
                            }
                        )

                        if (viewModel.isEditing) {
                            EditItemForm(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

data class Category(
    val name: String,
    val items: List<String>
)

@Composable
private fun CategoryHeader(
    text: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = text,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primaryContainer)
            .padding(16.dp)
    )
}

@Composable
private fun CategoryItem(
    text: String,
    onRemoveClick: () -> Unit,
    onEditClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = text,
            fontSize = 14.sp,
            modifier = Modifier.weight(1f)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )
        IconButton(
            onClick = onEditClick,
            modifier = Modifier.padding(end = 8.dp)
        ) {
            Icon(Icons.Filled.Edit, contentDescription = "Edytuj")
        }
        IconButton(
            onClick = onRemoveClick,
            modifier = Modifier.padding(end = 8.dp)
        ) {
            Icon(Icons.Filled.Delete, contentDescription = "Usuń")
        }
    }
}

@Composable
private fun CategorizedLazyColumn(
    categories: List<Category>,
    modifier: Modifier = Modifier,
    onItemRemove: (String) -> Unit,
    onItemEdit: (String) -> Unit
) {
    LazyColumn(
        modifier = modifier
    ) {
        categories.forEach { category ->
            stickyHeader {
                CategoryHeader(category.name)
            }
            items(category.items) { text ->
                CategoryItem(
                    text = text,
                    onRemoveClick = { onItemRemove(text) },
                    onEditClick = { onItemEdit(text) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddItemSection(
    onAddClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var text by remember { mutableStateOf("") }

    Column(modifier = modifier.padding(16.dp)) {
        TextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Wprowadź nowy element") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                onAddClick(text)
                text = ""
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Dodaj")
        }

    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditItemForm(viewModel: CategoryListViewModel) {
    var editedValue by remember { mutableStateOf(viewModel.editedItem) }

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = editedValue,
            onValueChange = { editedValue = it },
            label = { Text("Edytuj element") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Button(
                onClick = {
                    viewModel.editItem(editedValue)
                    viewModel.isEditing = false
                    viewModel.editedItem = ""
                },
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Text("Zapisz")
            }
            Button(
                onClick = {
                    viewModel.isEditing = false
                    viewModel.editedItem = ""
                }
            ) {
                Text("Anuluj")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    CategorizedLazyColumnTheme {
        Surface {
            val viewModel = CategoryListViewModel()
            Column {
                AddItemSection(onAddClick = viewModel::addItem)
                CategorizedLazyColumn(
                    categories = viewModel.namesList.value,
                    onItemRemove = viewModel::removeItem,
                    onItemEdit = { viewModel.editedItem = it; viewModel.isEditing = true }
                )
            }
        }
    }
}
