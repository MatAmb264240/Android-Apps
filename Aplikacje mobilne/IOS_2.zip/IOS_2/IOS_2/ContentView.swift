import SwiftUI

// Model danych dla żartu
struct Joke: Identifiable, Decodable {
    let id = UUID()
    let setup: String
    let delivery: String
    let imageUrl: String
    var wasPresented: Bool = false
    
    enum CodingKeys: String, CodingKey {
        case setup
        case delivery
        case imageUrl
    }
}

// Model danych dla odpowiedzi z API
struct JokeAPIResponse: Decodable {
    let jokes: [APIJoke]
    
    struct APIJoke: Decodable {
        let type: String
        let setup: String?
        let delivery: String?
        
        var joke: Joke? {
            if type == "twopart", let setup = setup, let delivery = delivery {
                let imageUrl = "https://picsum.photos/200/300?random=\(UUID().uuidString)"
                return Joke(setup: setup, delivery: delivery, imageUrl: imageUrl)
            }
            return nil
        }
    }
}

// Główny widok aplikacji
struct ContentView: View {
    @State private var jokes: [Joke] = []
    @State private var loadingMoreJokes = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach($jokes) { $joke in
                    NavigationLink(destination: JokeDetailView(joke: $joke, onAppear: checkIfAllJokesPresented)) {
                        HStack {
                            Text(joke.setup)
                                .foregroundColor(joke.wasPresented ? .gray : .primary)
                                .padding()
                                .background(joke.wasPresented ? Color.gray.opacity(0.2) : Color.blue.opacity(0.2))
                                .cornerRadius(10)
                                .shadow(color: joke.wasPresented ? Color.gray : Color.blue, radius: 5, x: 0, y: 2)
                                .scaleEffect(joke.wasPresented ? 0.95 : 1.0)
                                .animation(.easeInOut(duration: 0.3), value: joke.wasPresented)
                            
                            if joke.wasPresented {
                                Image(systemName: "checkmark")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Jokes")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        loadJokes()
                    }) {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
            .onAppear {
                if jokes.isEmpty {
                    loadJokes()
                }
            }
        }
    }
    
    // Funkcja do ładowania żartów z API
    func loadJokes() {
        guard let url = URL(string: "https://v2.jokeapi.dev/joke/Programming?type=twopart&amount=5") else {
            print("Invalid URL")
            return
        }
        
        loadingMoreJokes = true
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                do {
                    let apiResponse = try JSONDecoder().decode(JokeAPIResponse.self, from: data)
                    let newJokes = apiResponse.jokes.compactMap { $0.joke }
                    DispatchQueue.main.async {
                        jokes.append(contentsOf: newJokes)
                        loadingMoreJokes = false
                    }
                } catch {
                    print("Error decoding JSON: \(error)")
                    DispatchQueue.main.async {
                        loadingMoreJokes = false
                    }
                }
            } else if let error = error {
                print("Network error: \(error)")
                DispatchQueue.main.async {
                    loadingMoreJokes = false
                }
            }
        }.resume()
    }
    
    // Funkcja do sprawdzania, czy wszystkie żarty zostały przeglądnięte
    func checkIfAllJokesPresented() {
        if !loadingMoreJokes && jokes.allSatisfy({ $0.wasPresented }) {
            loadJokes()
        }
    }
}

// Widok szczegółowy dla wybranego żartu
struct JokeDetailView: View {
    @Binding var joke: Joke
    var onAppear: () -> Void
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text(joke.setup)
                    .font(.headline)
                    .padding(.bottom, 5)
                Text(joke.delivery)
                    .font(.body)
                if let url = URL(string: joke.imageUrl) {
                    AsyncImage(url: url) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                            .transition(.scale)
                            .animation(.easeInOut(duration: 0.5), value: joke.imageUrl)
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(height: 300)
                }
            }
            .padding()
            .background(
                LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.3)]), startPoint: .top, endPoint: .bottom)
                    .cornerRadius(20)
                    .shadow(radius: 10)
            )
            .padding()
            .navigationTitle("Joke Detail")
            .onAppear {
                joke.wasPresented = true
                onAppear()
            }
        }
    }
}

// Previews
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
