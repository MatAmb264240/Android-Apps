//
//  IOS_2App.swift
//  IOS_2
//
//  Created by Student15 on 04/06/2024.
//

import SwiftUI

@main
struct IOS_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
