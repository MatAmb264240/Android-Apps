package com.example.bikesrentalapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Delete

@Dao
interface BikeDao {

    @Query("SELECT * FROM bike_table")
    fun getAll(): List<Bike>

    @Query("SELECT * FROM bike_table WHERE id LIKE :bikeId LIMIT 1")
    suspend fun findByBikeId(bikeId: Int): Bike

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(bike: Bike)

    @Delete
    suspend fun delete(bike: Bike)

    @Query("DELETE FROM bike_table")
    suspend fun deleteAll()
}
