package com.example.bikerentalfinal

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.bikesrentalapp.data.Bike

class BikeAdapter(
    private val bikes: List<Bike>,
    private val onClick: (Bike) -> Unit
) : RecyclerView.Adapter<BikeAdapter.BikeViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BikeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_bike, parent, false)
        return BikeViewHolder(view)
    }

    override fun onBindViewHolder(holder: BikeViewHolder, position: Int) {
        val bike = bikes[position]
        holder.bind(bike)
    }

    override fun getItemCount() = bikes.size

    inner class BikeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val bikeImage: ImageView = itemView.findViewById(R.id.bike_image)
        private val bikeBrand: TextView = itemView.findViewById(R.id.bike_brand)
        private val bikeModel: TextView = itemView.findViewById(R.id.bike_model)

        init {
            itemView.setOnClickListener {
                onClick(bikes[adapterPosition])
            }
        }

        fun bind(bike: Bike) {
            bikeBrand.text = bike.brand
            bikeModel.text = bike.model

            // Use Glide to load the bike image
            Glide.with(itemView.context)
                .load(bike.imageUrl)
                .placeholder(R.drawable.placeholder_image) // Placeholder image
                .error(R.drawable.error_image) // Error image
                .into(bikeImage)

            bikeImage.setOnClickListener {
                val context = itemView.context
                val intent = Intent(context, BikeDetailActivity::class.java).apply {
                    putExtra("bikeBrand", bike.brand)
                    putExtra("bikeModel", bike.model)
                    putExtra("bikeId", bike.bikeId)
                    putExtra("bikeImageUrl", bike.imageUrl)
                }
                context.startActivity(intent)
            }
        }
    }
}
