package com.example.bikerentalfinal

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bikesrentalapp.data.AppDatabase
import com.example.bikesrentalapp.data.Bike
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AllBikesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: BikeAdapter
    private lateinit var appDb: AppDatabase
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_bikes)

        appDb = AppDatabase.getDatabase(this)

        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = GridLayoutManager(this, 3)

        fetchBikes()
    }

    private fun fetchBikes() {
        coroutineScope.launch {
            val bikes = appDb.bikeDao().getAll()
            withContext(Dispatchers.Main) {
                adapter = BikeAdapter(bikes) { bike ->
                    showBikeDetails(bike)
                }
                recyclerView.adapter = adapter
            }
        }
    }

    private fun showBikeDetails(bike: Bike) {
        Toast.makeText(this, "Brand: ${bike.brand}, Model: ${bike.model}, ID: ${bike.bikeId}", Toast.LENGTH_LONG).show()
    }
}
