package com.example.bikerentalfinal;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BikeDetailActivity extends AppCompatActivity {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bike_detail)

        // Get bike details from the intent
        val bikeBrand = intent.getStringExtra("bikeBrand")
        val bikeModel = intent.getStringExtra("bikeModel")
        val bikeId = intent.getIntExtra("bikeId", -1)
        val bikeImageUrl = intent.getStringExtra("bikeImageUrl")

        // Find views
        val bikeImage: ImageView = findViewById(R.id.bike_image_detail)
        val bikeBrandTextView: TextView = findViewById(R.id.bike_brand_detail)
        val bikeModelTextView: TextView = findViewById(R.id.bike_model_detail)
        val bikeIdTextView: TextView = findViewById(R.id.bike_id_detail)

        // Set bike details
        bikeBrandTextView.text = "Brand: $bikeBrand"
        bikeModelTextView.text = "Model: $bikeModel"
        bikeIdTextView.text = "Bike ID: $bikeId"

        // Load bike image
        Glide.with(this)
                .load(bikeImageUrl)
                .placeholder(R.drawable.placeholder_image)
                .error(R.drawable.error_image)
                .into(bikeImage)
    }
}